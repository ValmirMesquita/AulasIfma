/* Arquivo hello_world.c
Autor: Valmir S Mesquita 
Data:03/12/2024
1 Primeiro programa em C 
*/

#include <stdio.h>
int	main()
{

     printf("Hello World!.\n");
   
    system("pause");
    return 0;
}

