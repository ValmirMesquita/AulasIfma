#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#define NUMERO_PI 3.1415926535897932384626433832795028841971693993751L
int main()
{                  
    system("cls");
    long double d = 3.1415926535897932384626433832795028841971693993751;
    printf("%.30Lf\n",acosl(-1));
    printf("%.30Lf\n",d);

    printf("%.30Lf\n",NUMERO_PI);
    return 0;
}
