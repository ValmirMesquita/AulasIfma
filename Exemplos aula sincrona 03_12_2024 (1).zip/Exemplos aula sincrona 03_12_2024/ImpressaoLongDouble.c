#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main()
{
    long double a = acosl(-1);
    printf("%0.40Lf\n",a);
    return 0;
}