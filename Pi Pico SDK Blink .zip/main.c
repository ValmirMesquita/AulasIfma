#include "pico/stdlib.h"

#define LED_PIN 11
#define BT_PIN 5


int main() {
  
    // Define BT_PIN como entrada
    gpio_init(LED_PIN);
    gpio_set_dir(LED_PIN, GPIO_OUT);

    gpio_init(BT_PIN);
    gpio_set_dir(BT_PIN, GPIO_IN);
   
    while (1)
    {
       while (gpio_get(BT_PIN))
    {
        gpio_put(LED_PIN,1);
    }
    gpio_put(LED_PIN,0);
    }
       
    
        
   
}

